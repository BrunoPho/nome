<?php
defined('BASEPATH') OR exit ('no direct script access allowed');
class Helloworld extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		//load model
		$this->load->model('helloworld_model')
	}

	public function index()
	{
		//get data froma database 
		$deta['result'] = $this->helloworld_model->getData();

		//load view and pass the data 
		$this->load->view('helloworld_view', "data");
	}
}
?>